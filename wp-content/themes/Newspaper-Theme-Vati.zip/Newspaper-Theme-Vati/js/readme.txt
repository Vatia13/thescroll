- the javascript used by the theme is located in /js/full_compact

if you are looking for the minified version, it is located in /js/min . Minified/recompiled by Closure Compiler


