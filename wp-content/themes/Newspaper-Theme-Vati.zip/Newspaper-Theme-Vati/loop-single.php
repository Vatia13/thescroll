<?php
/**
 * The single post loop - This shows only one post
 **/

if (have_posts()) {
    the_post();
    global $numpages;
    $td_mod_single = new td_module_1($post);



    //show the breadcrumb
    if (get_post_type($post) == 'post') {
        echo td_page_generator::get_single_breadcrumbs($td_mod_single->title);
    } else {
        echo td_page_generator::get_page_breadcrumbs($td_mod_single->title);
    }
    ?>
    <?php if(is_single()):?>
        <div class="show-on-scroll">
            <div>
                <?php echo $td_mod_single->get_post_pagination();?>
            </div>
        </div>
    <?php endif;?>

        <article id="post-<?php echo $td_mod_single->post->ID;?>" class="<?php echo join(' ', get_post_class());?>" <?php echo $td_mod_single->get_item_scope();?>>

        <header>

            <?php echo $td_mod_single->get_title();?>

            <div class="meta-info">
                <?php //echo $td_mod_single->get_category();?>

                <?php echo $td_mod_single->get_date(true);?> | <?php echo $td_mod_single->get_author();?>
                <?php //echo $td_mod_single->get_commentsAndViews();?>
            </div>
        </header>
            <?php echo $td_mod_single->get_social_sharing();?>
            <?php echo $td_mod_single->get_social_like_tweet();?>
            <?php
            //add the top ad
            if (td_util::is_ad_spot_enabled('content_top') and is_single()) {
                echo td_global_blocks::get_instance('td_ad_box')->render(array('spot_id' => 'content_top'));
            }
            ?>
        <?php if (!empty($td_mod_single->td_post_theme_settings['td_subtitle'])) { ?>
            <p class="td-sub-title"><?php echo $td_mod_single->td_post_theme_settings['td_subtitle'];?></p>
        <?php } ?>


        <?php
        // override the default featured image by the templates (single.php and home.php/index.php - blog loop)
        if (!empty(td_global::$load_featured_img_from_template)) {
            echo $td_mod_single->get_image(td_global::$load_featured_img_from_template);
        } else {
            echo $td_mod_single->get_image('featured-image');
        }
        ?>

        <div class="td-post-text-content">
            <?php echo $td_mod_single->get_content();?>
        </div>


        <div class="clearfix"></div>

        <footer>
            <?php echo $td_mod_single->get_post_pagination();?>
            <?php echo $td_mod_single->get_review();?>
            <?php echo $td_mod_single->get_source_and_via();?>

            <?php echo $td_mod_single->get_next_prev_posts();?>
            <?php echo $td_mod_single->get_author_box();?>


            <?php echo $td_mod_single->get_item_scope_meta();?>
            <div class="post-bottom-ad">
                <?php
                //add the bottom 3 ad
                if (td_util::is_ad_spot_enabled('custom_ad_3') and is_single()) {
                    echo td_global_blocks::get_instance('td_ad_box')->render(array('spot_id' => 'custom_ad_3'));
                }
                ?>
            </div>
        </footer>

    </article> <!-- /.post -->
    <?php if($numpages > 1):?>
        <script>
            jQuery(document).ready(function($){
                topPagination($);
            });
        </script>
    <?php endif;?>
    <?php// echo $td_mod_single->related_posts();?>

<?php
} else {
    //no posts
    echo td_page_generator::no_posts();
}?>